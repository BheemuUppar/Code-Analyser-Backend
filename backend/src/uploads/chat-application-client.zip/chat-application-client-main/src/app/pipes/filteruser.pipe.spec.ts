import { FilteruserPipe } from './filteruser.pipe';

describe('FilteruserPipe', () => {
  it('create an instance', () => {
    const pipe = new FilteruserPipe();
    expect(pipe).toBeTruthy();
  });
});
